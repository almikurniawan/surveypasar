/**
 * @license Highcharts JS v9.1.2 (2021-06-16)
 * @module highcharts/themes/high-contrast-light
 * @requires highcharts
 *
 * (c) 2009-2021 Highsoft AS
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../Extensions/Themes/HighContrastLight.js';
