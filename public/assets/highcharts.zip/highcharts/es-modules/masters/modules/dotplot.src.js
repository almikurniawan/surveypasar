/**
 * @license Highcharts JS v9.1.2 (2021-06-16)
 * @module highcharts/modules/dotplot
 * @requires highcharts
 *
 * Dot plot series type for Highcharts
 *
 * (c) 2010-2021 Torstein Honsi
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../Series/DotPlot/DotPlotSeries.js';
