/**
 * @license Highcharts JS v9.1.2 (2021-06-16)
 * @module highcharts/modules/drilldown
 * @requires highcharts
 *
 * Highcharts Drilldown module
 *
 * Author: Torstein Honsi
 * License: www.highcharts.com/license
 *
 */
'use strict';
import '../../Extensions/Drilldown.js';
