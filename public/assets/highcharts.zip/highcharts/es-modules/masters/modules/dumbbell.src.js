/**
 * @license Highcharts JS v9.1.2 (2021-06-16)
 * @module highcharts/modules/dumbbell
 * @requires highcharts
 *
 * (c) 2009-2021 Sebastian Bochan, Rafal Sebestjanski
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../Series/Dumbbell/DumbbellSeries.js';
