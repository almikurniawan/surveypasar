<?php
    echo '<ul class="navbar-nav mr-auto">'.$menu.'</ul>';
